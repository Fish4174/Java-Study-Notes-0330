public class Drink
{
    public String name;//饮料名称
    public double price;//价格
    public int stock;//库存
    public double sales;//销售额
    public static final int MAXSTOCK=100;//允许的最大库存量
    //无参构造方法
    public Drink(){}
    //带参数name
    public Drink(String name)
    {
        this(name,0.0,0);
    }
    //带三个参数构造方法
    public Drink(String name,double price,int stock)//方法重载
    {
        this.name=name;
        this.price=price;
        this.stock=stock;
        this.sales=0;
    }
    public String getName()
    {
        return this.name;
    }
    public double getPrice()
    {
        return this.price;
    }
    public int getStock()
    {
        return this.stock;
    }
    public double getSales()
    {
        return this.sales;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setPrice(double price)
    {
        this.price=price;
    }
    public void setStock(int stock)
    {
        this.stock=stock;
    }
    public void setSales(double sales)
    {
        this.sales=sales;
    }
    public void decreaseStock(double money)
    {
        if(this.stock>=1)
        {
            this.stock--;
            money-=this.price;
            this.sales+=this.price;
            System.out.println("您成功购买了一杯"+this.name+",找零钱"+money+"元。");
        }
    }
    public void addStock(int amount)
    {
        if(this.stock+amount>=MAXSTOCK)
        {
            this.stock=MAXSTOCK;
            System.out.println(this.name+"库存已经补满，当前库存"+MAXSTOCK+"杯。");
            return;
        }
        if(amount>0)
        {
            this.stock+=amount;
        }
        System.out.println(this.name+"补货成功，当前库存"+this.stock+"杯。");
    }
    public void printInfo()
    {
        System.out.println("饮料："+name+" | 价格："+price+"元 | 库存："+stock+"杯 | 销售额："+sales+"元");
    }
}
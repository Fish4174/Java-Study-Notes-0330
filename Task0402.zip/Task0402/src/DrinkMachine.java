public class DrinkMachine
{
    public boolean makeDrink(Drink drink,double money)
    {
        if(money<drink.getPrice())
        {
            System.out.println("金额不足，销售失败！");
            return false;
        }
        if(drink.getStock()<1)
        {
            System.out.println(drink.getName()+"已售罄，销售失败！");
            return false;
        }
        System.out.println("饮料机正在制作"+drink.getName());
        drink.decreaseStock(money);
        return true;
    }
    public void fillDrink(Drink drink,int amount)
    {
        drink.addStock(amount);
    }
    public void staticMoney(Drink[] drinks)
    {
        double totalMoney=0.0;
        for(int i=0;i<drinks.length;i++)
        {
            totalMoney+=drinks[i].sales;
        }
        System.out.println("今天的销售额是"+totalMoney+"元钱。");
    }
}

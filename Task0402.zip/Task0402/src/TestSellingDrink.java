public class TestSellingDrink
{
    public static void main(String[] args)
    {
        Drink cola=new Drink("可乐",1.5,2);
        Drink milk=new Drink("营养快线",4,5);
        System.out.println("-------饮料机饮料信息如下-------");
        cola.printInfo();
        milk.printInfo();
        System.out.println("-----------------------------");
        DrinkMachine machine=new DrinkMachine();
        double money=5;
        System.out.println("投入"+money+"元，购买第一杯可乐...");
        if(machine.makeDrink(cola,money)) money-=cola.price;
        System.out.println("投入"+money+"元，购买第二杯可乐..."        );
        if(machine.makeDrink(cola,money)) money-=cola.price;
        System.out.println("投入"+money+"元，购买第三杯可乐...");
        if(machine.makeDrink(cola,money)) money-=cola.price;
        System.out.println("投入"+money+"元，购买第一杯营养快线...");
        if(machine.makeDrink(milk,money)) money-=milk.price;
        money+=5;
        System.out.println("投入"+money+"元，购买第一杯营养快线...");
        if(machine.makeDrink(milk,money)) money-=milk.price;
        machine.fillDrink(cola,10);
        Drink[] drinks=new Drink[2];
        drinks[0]=cola;
        drinks[1]=milk;
        machine.staticMoney(drinks);
    }
}
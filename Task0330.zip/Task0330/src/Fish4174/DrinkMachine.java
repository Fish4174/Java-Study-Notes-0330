package Fish4174;

public class DrinkMachine
{
    public boolean makeDrink(Drink drink,double money)
    {
        if(money<drink.getPrice())
        {
            System.out.println("金额不足，销售失败！");
            return false;
        }
        if(drink.getStock()<1)
        {
            System.out.println(drink.getName()+"已售罄，销售失败！");
            return false;
        }
        System.out.println("饮料机正在制作"+drink.getName());
        drink.decreaseStock(money);
        return true;
    }
}
